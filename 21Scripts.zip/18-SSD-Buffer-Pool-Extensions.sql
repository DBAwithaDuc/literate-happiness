-- ------------------------------------------------------
-- Script 18: How to overcome MEMORY bottlenecks?
-- (c) https://blog.sqlauthority.com
-- Subscribe to newsletter at https://go.sqlauthority.com 
-- Questions: pinal@sqlauthority.com 
-- ------------------------------------------------------

/*
In this demostration we will see how we can overcome the memory limitations. 
*/
-- Demo to show Buffer Pool extensions

-- Let us limit the memory and keep it
EXEC sys.sp_configure N'show advanced options', N'1'  
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'max server memory (MB)', N'512'
GO
RECONFIGURE WITH OVERRIDE
GO

-- Restart services

-- How to enable Buffer Pool Extensions

-- Assumption here is d:\ is a fast SSD drive.
-- Works on normal drives too. But performance may vary.
ALTER SERVER CONFIGURATION 
SET BUFFER POOL EXTENSION 
ON ( FILENAME = 'd:\data\BPE.bpe' ,SIZE = 24 GB);



-- DMV to get the above configuration information
SELECT * 
FROM sys.dm_os_buffer_pool_extension_configuration;


-- Let us create a load


SELECT *
FROM sys.dm_os_buffer_descriptors
WHERE is_in_bpool_extension = 1


-- Disable the Buffer Pool Extension
ALTER SERVER CONFIGURATION
SET BUFFER POOL EXTENSION OFF

-- Clean up time
-- Bring the memory back to normal
EXEC sys.sp_configure N'show advanced options', N'1'  
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'max server memory (MB)', N'16777216'
GO
RECONFIGURE WITH OVERRIDE
GO