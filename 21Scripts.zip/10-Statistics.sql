-- ------------------------------------------------------
-- Script 10: How does STATISTICS plays role in performance tuning?
-- (c) https://blog.sqlauthority.com
-- Subscribe to newsletter at https://go.sqlauthority.com 
-- Questions: pinal@sqlauthority.com 
-- ------------------------------------------------------

/*
Important of Statistics in SQL Server Performance Tuning
*/

USE [master]
GO
/*
ALTER DATABASE StatusON
SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DROP DATABASE StatusON;
ALTER DATABASE StatusOFF
SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DROP DATABASE StatusOFF;
GO
*/
/* DB Creation */
CREATE DATABASE StatusON
GO
CREATE DATABASE StatusOFF
GO
------ Statistics ON
USE [master]
GO
ALTER DATABASE StatusON SET AUTO_CREATE_STATISTICS ON WITH NO_WAIT
GO
ALTER DATABASE StatusON SET AUTO_UPDATE_STATISTICS ON WITH NO_WAIT
GO
------ Statistics OFF
USE [master]
GO
ALTER DATABASE StatusOFF SET AUTO_CREATE_STATISTICS OFF WITH NO_WAIT
GO
ALTER DATABASE StatusOFF SET AUTO_UPDATE_STATISTICS OFF WITH NO_WAIT
GO
--

-------------------------------------------------------------------------
/* Table Creation StatusON */
USE StatusON
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StatusONTable]') AND type in (N'U'))
DROP TABLE [dbo].[StatusONTable]
GO
-- Create Table StatusONTable
CREATE TABLE StatusONTable (ID INT, 
						FirstName VARCHAR(100), 
						LastName VARCHAR(100), 
						City VARCHAR(100))
GO
-- Create Clustered Index
CREATE CLUSTERED INDEX [IX_StatusONTable_ID] ON [dbo].[StatusONTable]
(
	[ID] ASC
)  ON [PRIMARY]
GO
-- Create non-clustered Index
CREATE NONCLUSTERED INDEX [IX_StatusONTable_FirstName] ON [dbo].[StatusONTable]
(
	[FirstName] ASC
)  ON [PRIMARY]
GO


-------------------------------------------------------------------------
/* Table Creation StatusOFF */
USE StatusOFF
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StatusOFFTable]') AND type in (N'U'))
DROP TABLE [dbo].[StatusOFFTable]
GO
-- Create Table StatusONTable
CREATE TABLE StatusOFFTable (ID INT, 
						FirstName VARCHAR(100), 
						LastName VARCHAR(100), 
						City VARCHAR(100))
GO
-- Create Clustered Index
CREATE CLUSTERED INDEX [IX_StatusOFFTable_ID] ON [dbo].[StatusOFFTable]
(
	[ID] ASC
)  ON [PRIMARY]
GO
-- Create non-clustered Index
CREATE NONCLUSTERED INDEX [IX_StatusOFFTable_FirstName] ON [dbo].[StatusOFFTable]
(
	[FirstName] ASC
)  ON [PRIMARY]
GO

/* Populate the tables */
INSERT INTO StatusON.dbo.StatusONTable (ID,FirstName,LastName,City)
SELECT TOP 10000 ROW_NUMBER() OVER (ORDER BY a.name) RowID, 
					'Mike'+ CAST(ROW_NUMBER() OVER (ORDER BY a.name)%1000 AS VARCHAR), 
					CASE WHEN  ROW_NUMBER() OVER (ORDER BY a.name)%2 = 1 THEN 'Smith' 
					ELSE 'Brown' END,
					CASE WHEN ROW_NUMBER() OVER (ORDER BY a.name)%10 = 1 THEN 'New York' 
						WHEN  ROW_NUMBER() OVER (ORDER BY a.name)%10 = 5 THEN 'San Marino' 
						WHEN  ROW_NUMBER() OVER (ORDER BY a.name)%10 = 3 THEN 'Los Angeles' 
					ELSE 'Houston' END
FROM sys.all_objects a
CROSS JOIN sys.all_objects b
GO 
INSERT INTO StatusOFF.dbo.StatusOFFTable (ID,FirstName,LastName,City)
SELECT TOP 10000 ROW_NUMBER() OVER (ORDER BY a.name) RowID, 
					'Mike'+ CAST(ROW_NUMBER() OVER (ORDER BY a.name)%1000 AS VARCHAR), 
					CASE WHEN  ROW_NUMBER() OVER (ORDER BY a.name)%2 = 1 THEN 'Smith' 
					ELSE 'Brown' END,
					CASE WHEN ROW_NUMBER() OVER (ORDER BY a.name)%10 = 1 THEN 'New York' 
						WHEN  ROW_NUMBER() OVER (ORDER BY a.name)%10 = 5 THEN 'San Marino' 
						WHEN  ROW_NUMBER() OVER (ORDER BY a.name)%10 = 3 THEN 'Los Angeles' 
					ELSE 'Houston' END
FROM sys.all_objects a
CROSS JOIN sys.all_objects b
GO 
SET STATISTICS IO ON
/* Running Queries AGAIN CTRL+M */
SELECT *
FROM StatusON.dbo.StatusONTable
WHERE FirstName = 'Mike0'
GO
SELECT *
FROM StatusOFF.dbo.StatusOFFTable
WHERE FirstName = 'Mike0'
GO

/* Clean Up */
USE master;
DROP DATABASE StatusON;
DROP DATABASE StatusOFF;
GO
