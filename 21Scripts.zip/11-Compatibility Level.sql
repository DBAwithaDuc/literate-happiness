-- ------------------------------------------------------
-- Script 11c: How does COMPATIBILITY Level plays role in performance tuning?
-- (c) https://blog.sqlauthority.com
-- Subscribe to newsletter at https://go.sqlauthority.com 
-- Questions: pinal@sqlauthority.com 
-- ------------------------------------------------------
/*
Turn on Legacy Cardinality for trouble making queries
*/
/*
Warning: Please test the change of compatibility level on developement 
			server before changing it on the production server.
*/

USE WideWorldImporters
GO
SET STATISTICS IO ON 
GO
-- SQL Server 2012

ALTER DATABASE WideWorldImporters 
SET COMPATIBILITY_LEVEL = 110
GO
SELECT * -- Query 1
FROM sales.Invoices i
INNER JOIN sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
WHERE i.AccountsPersonID = 2001 
		AND i.DeliveryMethodID = 3
GO	

USE WideWorldImporters
GO
-- SQL Server 2014
ALTER DATABASE WideWorldImporters 
SET COMPATIBILITY_LEVEL = 120
GO
SELECT * -- Query 2
FROM sales.Invoices i
INNER JOIN sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
WHERE i.AccountsPersonID = 2001 
		AND i.DeliveryMethodID = 3
GO	

USE WideWorldImporters
GO
-- SQL Server 2016
ALTER DATABASE WideWorldImporters 
SET COMPATIBILITY_LEVEL = 130
GO
SELECT * -- Query 3
FROM sales.Invoices i
INNER JOIN sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
WHERE i.AccountsPersonID = 2001 
		AND i.DeliveryMethodID = 3
GO	

USE WideWorldImporters
GO
-- SQL Server 2017
ALTER DATABASE WideWorldImporters 
SET COMPATIBILITY_LEVEL = 140
GO
SELECT * -- Query 4
FROM sales.Invoices i
INNER JOIN sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
WHERE i.AccountsPersonID = 2001 
		AND i.DeliveryMethodID = 3
GO

DBCC FREEPROCCACHE
GO

-- Here is the way to force the older cardinality estimator model
SELECT * -- Query 5
FROM sales.Invoices i
INNER JOIN sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
WHERE i.AccountsPersonID = 2001 
		AND i.DeliveryMethodID = 3
OPTION (USE HINT('FORCE_LEGACY_CARDINALITY_ESTIMATION'));
--OPTION (QUERYTRACEON 9481);
GO	